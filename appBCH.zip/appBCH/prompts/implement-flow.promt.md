# Flow Implementation Prompt

Use the provided documentation files as the source of truth.

Priority order:
1. components.md
2. layout-rules.md
3. design.md
4. flow specification

Do not recreate Figma screens literally.

The implementation must use:
- existing components
- existing layout rules
- existing interaction patterns
- existing responsive behavior

---

# Implementation Rules

Generate production-ready frontend code.

Requirements:
- reusable components
- semantic HTML
- accessibility support
- keyboard navigation
- responsive layouts
- modular architecture

---

# Architecture Rules

Generate code only inside `/src`.

Prefer:
- feature-based architecture
- composable sections
- reusable UI components
- isolated logic

Avoid:
- monolithic pages
- duplicated components
- inline styles
- hardcoded values
- unrelated files

---

# UI Rules

Preserve:
- spacing consistency
- alignment consistency
- hierarchy clarity
- enterprise usability

Do not invent:
- new design patterns
- new layout systems
- decorative styles
- inconsistent behaviors

---

# Form Rules

Forms must:
- preserve alignment
- support validation states
- avoid layout shifts
- remain responsive

---

# Accordion Rules

Accordion sections must:
- support expanded/collapsed state
- animate smoothly
- preserve layout structure

---

# Deliverables

Generate:
- page implementation
- reusable sections
- responsive layout
- interactions
- component composition

Do not generate:
- backend logic
- mock APIs
- fake services