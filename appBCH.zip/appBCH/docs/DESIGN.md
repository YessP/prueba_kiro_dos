# Metadata Design Tokens (BCH)

Fuente: archivo Figma `Design-System-BCH` (`89Gwuhhpk3FsYjsBY6QZZv`).

Este documento lista los tokens disponibles en el archivo como **Paint Styles**, **Text Styles**, **Effect Styles** y **Grid Styles** (ademas de las **Variables** locales encontradas). Los nombres se mantienen tal como estan en Figma.

Fecha de extraccion: 2026-05-07 (America/Santiago).
# Design Foundations

## Variables (Figma Variables)

Coleccion: `Variable collection`  
Modos: `Visa`, `Master`, `Mode 3`

| Token | Tipo | Visa | Master | Mode 3 |
|---|---|---|---|---|
| `Title` | `STRING` | `String value` | `String value` | `String value` |
| `step_number` | `STRING` | `String value` | `String value` | `String value` |
| `Text` | `STRING` | `Texto` | `Texto` | `Texto` |
| `value` | `STRING` | `Hug` | `String value` | `String value` |

## Colores y Fondos (Paint Styles)

Notas:
- `opacity` corresponde a la opacidad del paint (0 a 1).
- En gradientes, se listan los stops principales en formato `HEX@alpha (pos)`.

### Core palette (gray/white/brand/primary/auxiliar/Overlay)

| Token | Tipo | Valor | Descripcion |
|---|---|---|---|
| `gray/@dark` | `SOLID` | `#2A333D` (opacity 1.00) | Uso: Titulo, texto destacado o boton neutro |
| `gray/@base` | `SOLID` | `#52677B` (opacity 1.00) | Uso: Parrafos de textos |
| `gray/@light` | `SOLID` | `#8393A3` (opacity 1.00) | Uso: Iconos sin interaccion |
| `gray/@lighter` | `SOLID` | `#CED7E0` (opacity 1.00) | Uso: Bordes y elementos disabled |
| `gray/@background` | `SOLID` | `#F0F2F5` (opacity 1.00) | Uso: Fondos, bordes deshabilitados |
| `gray/@transparent` | `SOLID` | `#52677B` (opacity 0.16) | Uso: Fondos |
| `gray/@gradient` | `GRADIENT_LINEAR` | `#F0F3F5@1 (0) -> #FFFFFF@1 (1)` (opacity 1.00) |  |
| `white/@white` | `SOLID` | `#FFFFFF` (opacity 1.00) | Uso: Fondos, texto sobre fondo oscuro |
| `white/@transparent` | `SOLID` | `#FFFFFF` (opacity 0.16) |  |
| `brand/@dark-new` | `SOLID` | `#0A1861` (opacity 1.00) |  |
| `brand/@dark` | `SOLID` | `#001B4C` (opacity 1.00) |  |
| `brand/@base` | `SOLID` | `#002464` (opacity 1.00) |  |
| `brand/@light` | `SOLID` | `#002884` (opacity 1.00) |  |
| `brand/@lighter` | `SOLID` | `#A3C1F5` (opacity 1.00) |  |
| `brand/@background` | `SOLID` | `#F5F9FF` (opacity 1.00) |  |
| `brand/@gradient` | `GRADIENT_LINEAR` | `#002884@1 (0) -> #001B4C@1 (1)` (opacity 1.00) |  |
| `brand/@transparent` | `SOLID` | `#002464` (opacity 0.16) |  |
| `primary/@dark` | `SOLID` | `#0038E1` (opacity 1.00) |  |
| `primary/@base` | `SOLID` | `#295EFF` (opacity 1.00) |  |
| `primary/@light` | `SOLID` | `#5583FF` (opacity 1.00) |  |
| `primary/@lighter` | `SOLID` | `#A3B7F5` (opacity 1.00) |  |
| `primary/@background` | `SOLID` | `#FAFBFF` (opacity 1.00) |  |
| `primary/@gradient` | `GRADIENT_LINEAR` | `#5583FF@1 (0) -> #295EFF@1 (1)` (opacity 1.00) |  |
| `primary/@transparent` | `SOLID` | `#295EFF` (opacity 0.16) |  |
| `primary/custom/@FAN` | `SOLID` | `#00FFFF` (opacity 1.00) |  |
| `auxiliar/info/@dark` | `SOLID` | `#085B9E` (opacity 1.00) |  |
| `auxiliar/info/@base` | `SOLID` | `#0B78D0` (opacity 1.00) |  |
| `auxiliar/info/@light` | `SOLID` | `#0092FF` (opacity 1.00) |  |
| `auxiliar/info/@lighter` | `SOLID` | `#A3D0F5` (opacity 1.00) |  |
| `auxiliar/info/@background` | `SOLID` | `#F5FAFF` (opacity 1.00) |  |
| `auxiliar/success/@dark` | `SOLID` | `#176517` (opacity 1.00) |  |
| `auxiliar/success/@base` | `SOLID` | `#1E851E` (opacity 1.00) |  |
| `auxiliar/success/@light` | `SOLID` | `#18AC18` (opacity 1.00) |  |
| `auxiliar/success/@lighter` | `SOLID` | `#9BD49B` (opacity 1.00) |  |
| `auxiliar/success/@background` | `SOLID` | `#F5FFF5` (opacity 1.00) |  |
| `auxiliar/warning/@dark` | `SOLID` | `#7F5E32` (opacity 1.00) |  |
| `auxiliar/warning/@base` | `SOLID` | `#FDBC64` (opacity 1.00) |  |
| `auxiliar/warning/@light` | `SOLID` | `#FDC374` (opacity 1.00) |  |
| `auxiliar/warning/@lighter` | `SOLID` | `#F9EED0` (opacity 1.00) |  |
| `auxiliar/warning/@background` | `SOLID` | `#FFFCF5` (opacity 1.00) |  |
| `auxiliar/error/@dark` | `SOLID` | `#A12B00` (opacity 1.00) |  |
| `auxiliar/error/@base` | `SOLID` | `#D43900` (opacity 1.00) |  |
| `auxiliar/error/@light` | `SOLID` | `#FF3900` (opacity 1.00) |  |
| `auxiliar/error/@lighter` | `SOLID` | `#F5B9A3` (opacity 1.00) |  |
| `auxiliar/error/@background` | `SOLID` | `#FFF8F5` (opacity 1.00) |  |
| `auxiliar/error/@transparent` | `SOLID` | `#FF3900` (opacity 0.40) |  |
| `Overlay/Dark` | `SOLID` | `#2A333D` (opacity 0.60) | Se utiliza para los overlay |

### Special backup (special-backup/)

| Token | Tipo | Valor |
|---|---|---|
| `special-backup/credit-card/black-gradient` | `GRADIENT_LINEAR` | `#424243@1 (0.0296) -> #404040@1 (0.3408) -> #242424@1 (0.6555) -> #1F1F1F@1 (1)` |
| `special-backup/credit-card/gold-gradient` | `GRADIENT_LINEAR` | `#946F31@1 (0) -> #966F2E@1 (0.2566) -> #846939@1 (0.6924) -> #76613C@1 (1)` |
| `special-backup/credit-card/silver-gradient` | `GRADIENT_LINEAR` | `#8A8A8A@1 (0) -> #737373@1 (1)` |
| `special-backup/credit-card/signature` | `SOLID` | `#CBCBCC` (opacity 1.00) |
| `special-backup/credit-card/blocked/black-gradient` | `GRADIENT_LINEAR` + `IMAGE` | `#424243... -> #1F1F1F` + `IMAGE` (opacity 0.20, TILE) |
| `special-backup/credit-card/blocked/gold-gradient` | `GRADIENT_LINEAR` + `IMAGE` | `#946F31... -> #76613C` + `IMAGE` (opacity 0.20, TILE) |
| `special-backup/credit-card/blocked/silver-gradient` | `GRADIENT_LINEAR` + `IMAGE` | `#6A6A6A... -> #7F7F7F` + `IMAGE` (opacity 0.20, TILE) |
| `special-backup/credit-card/blocked/brand-gradient` | `GRADIENT_LINEAR` + `IMAGE` | `#002884@1 -> #001B4C@1` + `IMAGE` (opacity 0.20, TILE) |
| `special-backup/credit-card/blocked/fan-gradient` | `GRADIENT_LINEAR` + `IMAGE` | `#F0F3F5@1 -> #FFFFFF@1` + `IMAGE` (opacity 0.20, TILE) |
| `special-backup/credit-card/blocked/bec-gradient` | `GRADIENT_LINEAR` + `IMAGE` | `#00734D@1 -> #02422E@1` + `IMAGE` (opacity 0.20, TILE) |
| `special-backup/credit-card/Temporary blocked/black-gradient` | `GRADIENT_LINEAR` + `IMAGE` | `#424243... -> #1F1F1F` + `IMAGE` (opacity 0.60, TILE) |
| `special-backup/credit-card/Temporary blocked/gold-gradient` | `GRADIENT_LINEAR` + `IMAGE` | `#946F31... -> #76613C` + `IMAGE` (opacity 0.60, TILE) |
| `special-backup/credit-card/Temporary blocked/silver-gradient` | `GRADIENT_LINEAR` + `IMAGE` | `#6A6A6A... -> #7F7F7F` + `IMAGE` (opacity 0.60, TILE) |
| `special-backup/credit-card/Temporary blocked/brand-gradient` | `GRADIENT_LINEAR` + `IMAGE` | `#002884@1 -> #001B4C@1` + `IMAGE` (opacity 0.60, TILE) |
| `special-backup/credit-card/Temporary blocked/fan-gradient-white` | `GRADIENT_LINEAR` + `IMAGE` | `#F0F3F5@1 -> #FFFFFF@1` + `IMAGE` (opacity 0.60, TILE) |
| `special-backup/credit-card/Temporary blocked/fan-gradient-light-blue` | `GRADIENT_LINEAR` + `IMAGE` | `#009CDF@1 -> #236BE2@1` + `IMAGE` (opacity 0.60, TILE) |
| `special-backup/credit-card/Temporary blocked/bec-gradient` | `GRADIENT_LINEAR` + `IMAGE` | `#00734D@1 -> #02422E@1` + `IMAGE` (opacity 0.60, TILE) |
| `special-backup/app/gold-edwards` | `SOLID` | `#C4B264` (opacity 1.00) |
| `special-backup/app/green-dark-edwards` | `SOLID` | `#012B14` (opacity 1.00) |
| `special-backup/gradient/bch-gradient-right` | `GRADIENT_LINEAR` | `#295EFF@0.10 (0) -> #295EFF@0.0001 (1)` |
| `special-backup/gradient/white-bottom` | `GRADIENT_LINEAR` | `#FFFFFF@0.0001 (0) -> #FFFFFF@1 (1)` |
| `special-backup/gradient/white-top` | `GRADIENT_LINEAR` | `#FFFFFF@1 (0) -> #FFFFFF@0.0001 (1)` |
| `special-backup/gradient/bch-gradient-left` | `GRADIENT_LINEAR` | `#295EFF@0.10 (0) -> #295EFF@0.0001 (1)` |
| `special-backup/gradient/bch-gradient-bottom` | `GRADIENT_LINEAR` | `#295EFF@1 (0) -> #43B1FF@0.0042 (0.8562) -> #43B1FF@0.0001 (1)` |
| `special-backup/button/_pressed-bch-primary` | `GRADIENT_LINEAR` + `IMAGE` | `#5583FF@1 -> #295EFF@1` + `IMAGE` (opacity 0.60, FIT) |
| `special-backup/button/_pressed-bch-secondary` | `SOLID` + `IMAGE` | `#FFFFFF` + `IMAGE` (opacity 0.30, FIT) |
| `special-backup/button/_pressed-warning` | `SOLID` + `IMAGE` | `#FFFFFF` + `IMAGE` (opacity 0.40, FIT) |
| `special-backup/button/_pressed-neutral` | `SOLID` + `IMAGE` | `#FFFFFF` + `IMAGE` (opacity 0.60, FIT) |
| `special-backup/button/_pressed-neutral-inverse` | `SOLID` + `IMAGE` | `#FFFFFF` (opacity 0) + `IMAGE` (opacity 0.60, FIT) |
| `special-backup/credit-card/fan-gradient` | `GRADIENT_LINEAR` | `#009CDF@1 (0) -> #236BE2@1 (1)` |
| `special-backup/credit-card/bec-gradient` | `GRADIENT_LINEAR` | `#00734D@1 (0) -> #02422E@1 (1)` |
| `special-backup/soft (empty states)/bch/@base` | `SOLID` | `#99A9CE` (opacity 1.00) |
| `special-backup/soft (empty states)/bch/@lighter` | `SOLID` | `#E9F0FD` (opacity 1.00) |
| `special-backup/soft (empty states)/bch/@background` | `GRADIENT_LINEAR` | `#648EFF@1 (0) -> #A3C1F5@0 (1)` (opacity 0.15) |
| `special-backup/soft (empty states)/bec/@base` | `SOLID` | `#7BAE9D` (opacity 1.00) |
| `special-backup/soft (empty states)/bec/@lighter` | `SOLID` | `#E3F5F0` (opacity 1.00) |
| `special-backup/soft (empty states)/bec/@background` | `GRADIENT_LINEAR` | `#00734D@1 (0) -> #E3F5F0@1 (1)` (opacity 0.10) |
| `special-backup/soft (empty states)/warning/@base` | `SOLID` | `#FF914C` (opacity 1.00) |
| `special-backup/soft (empty states)/warning/@lighter` | `SOLID` | `#FDF1ED` (opacity 1.00) |
| `special-backup/soft (empty states)/warning/@background` | `GRADIENT_LINEAR` | `#FF7337@1 (0) -> #F5BAA3@0.30 (1)` (opacity 0.15) |
| `special-backup/other/favorite` | `SOLID` | `#FFD941` (opacity 1.00) |

### Deprecated ([Deprecated]/)

| Token | Tipo | Valor |
|---|---|---|
| `[Deprecated]/primary bec [Deprecated]/@dark` | `SOLID` | `#026353` (opacity 1.00) |
| `[Deprecated]/primary bec [Deprecated]/@base` | `SOLID` | `#03826D` (opacity 1.00) |
| `[Deprecated]/primary bec [Deprecated]/@light` | `SOLID` | `#00AB8D` (opacity 1.00) |
| `[Deprecated]/primary bec [Deprecated]/@lighter` | `SOLID` | `#9BD4CA` (opacity 1.00) |
| `[Deprecated]/primary bec [Deprecated]/@background` | `SOLID` | `#FAFFFE` (opacity 1.00) |
| `[Deprecated]/primary bec [Deprecated]/@gradient` | `GRADIENT_LINEAR` | `#00AB8D@1 (0) -> #03826D@1 (1)` |
| `[Deprecated]/primary bec [Deprecated]/@transparent` | `SOLID` | `#03826D` (opacity 0.16) |
| `[Deprecated]/special-backup [Deprecated]/brand-gradient/bec-gradient-bottom` | `GRADIENT_LINEAR` | `#00AB8D@1 (0) -> #43B1FF@0.0042 (0.8562) -> #43B1FF@0.0001 (1)` |
| `[Deprecated]/special-backup [Deprecated]/brand-gradient/bec-gradient-left` | `GRADIENT_LINEAR` | `#03826D@1 (0) -> #03826D@0.0001 (1)` |
| `[Deprecated]/special-backup [Deprecated]/brand-gradient/bec-gradient-right` | `GRADIENT_LINEAR` | `#00AB8D@1 (0) -> #43B1FF@0.0001 (1)` |
| `[Deprecated]/special-backup [Deprecated]/_utiliy-button/_pressed-bec-primary` | `GRADIENT_LINEAR` + `IMAGE` | `#00AB8D@1 -> #03826D@1` + `IMAGE` (opacity 0.60, FIT) |

## Tipografia (Text Styles)

Formato:
- `lineHeight`: `PIXELS` o `AUTO`
- `letterSpacing`: `PIXELS` o `PERCENT`

| Token | Font | Size | Line height | Letter spacing | Case |
|---|---:|---:|---:|---:|---|
| `big-heading/h2` | Nunito Sans Regular | 32 | AUTO | 0px | ORIGINAL |
| `headings/h1` | Nunito Sans Regular | 26 | 32px | 0px | ORIGINAL |
| `headings/h2` | Nunito Sans Regular | 24 | 32px | 0px | ORIGINAL |
| `headings/h3` | Nunito Sans Regular | 20 | 24px | 0px | ORIGINAL |
| `headings/h4` | Nunito Sans Bold | 16 | 24px | 0px | ORIGINAL |
| `headings/h5` | Nunito Sans Bold | 14 | 24px | 0px | ORIGINAL |
| `headings/h6` | Nunito Sans Bold | 12 | 24px | 0px | UPPER |
| `bold/h1` | Nunito Sans Bold | 26 | 32px | 0px | ORIGINAL |
| `bold/h2` | Nunito Sans Bold | 24 | 32px | 0px | ORIGINAL |
| `bold/h3` | Nunito Sans Bold | 20 | 24px | 0px | ORIGINAL |
| `body/p` | Nunito Sans Regular | 16 | 24px | 0px | ORIGINAL |
| `body/p.small` | Nunito Sans Regular | 14 | 24px | 0px | ORIGINAL |
| `body/p.smaller` | Nunito Sans Regular | 12 | 24px | 0px | ORIGINAL |
| `body/p.smaller.line-height` | Nunito Sans Regular | 12 | 16px | 0px | ORIGINAL |
| `bold/p` | Nunito Sans Bold | 16 | 24px | 0px | ORIGINAL |
| `bold/p.small` | Nunito Sans Bold | 14 | 24px | 0px | ORIGINAL |
| `bold/p.smaller` | Nunito Sans Bold | 12 | 24px | 0px | ORIGINAL |
| `bold/p.smaller.line-height` | Nunito Sans Bold | 12 | 16px | 0px | ORIGINAL |
| `small-heading/small-heading` | Nunito Sans Regular | 16 | 24px | 2px | UPPER |
| `small-heading/small-heading.small` | Nunito Sans Regular | 14 | 24px | 2px | UPPER |
| `small-heading/small-heading.smaller` | Nunito Sans Regular | 12 | 24px | 2px | UPPER |
| `small-heading/small-heading.smaller.line-height` | Nunito Sans Regular | 12 | 16px | 2px | UPPER |
| `small-heading/small-heading.tiny` | Nunito Sans SemiBold | 10 | 16px | 1px | UPPER |
| `bold/small-heading` | Nunito Sans Bold | 16 | 24px | 2px | UPPER |
| `bold/small-heading.small` | Nunito Sans Bold | 14 | 24px | 2px | UPPER |
| `bold/small-heading.smaller` | Nunito Sans Bold | 12 | 24px | 2px | UPPER |
| `bold/small-heading.smaller.line-height` | Nunito Sans Bold | 12 | 16px | 2px | UPPER |
| `subheadings/subheading` | Nunito Sans Regular | 16 | 24px | 2px | UPPER |
| `subheadings/subheading.small` | Nunito Sans Regular | 14 | 24px | 2px | UPPER |
| `subheadings/subheading.smaller` | Nunito Sans Regular | 12 | 24px | 2px | UPPER |
| `subheadings/subheading.smaller.line-height` | Nunito Sans Regular | 12 | 16px | 2px | UPPER |
| `bold/subheading` | Nunito Sans Bold | 16 | 24px | 2px | UPPER |
| `bold/subheading.small` | Nunito Sans Bold | 14 | 24px | 2px | UPPER |
| `bold/subheading.smaller` | Nunito Sans Bold | 12 | 24px | 2px | UPPER |
| `bold/subheading.smaller.line-height` | Nunito Sans Bold | 12 | 16px | 2px | UPPER |
| `label/top` | Nunito Sans Regular | 14 | 15px | 0px | ORIGINAL |
| `label/top-small` | Nunito Sans Regular | 12 | 14px | 0px | ORIGINAL |
| `button/BUTTON` | Nunito Sans Bold | 14 | 24px | 0.4px | UPPER |
| `button/BUTTON.bigger` | Nunito Sans Bold | 24 | 32px | 0.4px | UPPER |
| `button/BUTTON.SMALL` | Nunito Sans Bold | 12 | 24px | 0.4px | UPPER |
| `button/link` | Nunito Sans Bold | 14 | 24px | 0.4px | UPPER |
| `button/link.small` | Nunito Sans Bold | 12 | 24px | 0.4px | UPPER |
| `number/number` | Nunito Sans Bold | 14 | 24px | 1px | ORIGINAL |
| `number/number.small` | Nunito Sans Bold | 12 | 24px | 1px | ORIGINAL |
| `number/number.big` | Nunito Sans Bold | 20 | 24px | 1px | ORIGINAL |
| `number/number.bigger` | Nunito Sans Bold | 26 | 32px | 1px | ORIGINAL |
| `tooltip/tooltip.normal` | Nunito Sans Regular | 14 | 20px | 0px | ORIGINAL |
| `tooltip/tooltip.small` | Nunito Sans Regular | 12 | 16px | 0px | ORIGINAL |
| `tag/tag` | Nunito Sans Regular | 12 | 24px | 0px | UPPER |
| `tag/tag.titlecase` | Nunito Sans Regular | 12 | 24px | 0px | TITLE |
| `table/table-header` | Nunito Sans Bold | 12 | 24px | 0px | ORIGINAL |
| `legal/p` | Roboto Regular | 10 | 14px | 0% | ORIGINAL |
| `legal/p.line-height` | Roboto Regular | 10 | 12px | 0% | ORIGINAL |
| `escala-1024/headings/h1.1024` | Nunito Sans Regular | 18 | 24px | 0px | ORIGINAL |
| `escala-1024/headings/h2.1024` | Nunito Sans Regular | 16 | 24px | 0px | ORIGINAL |
| `escala-1024/headings/h3.1024` | Nunito Sans Regular | 14 | 24px | 0px | ORIGINAL |
| `escala-1024/headings/h4.1024` | Nunito Sans Bold | 14 | 24px | 0px | ORIGINAL |
| `escala-1024/headings/h5.1024` | Nunito Sans Bold | 12 | 20px | 0px | ORIGINAL |
| `escala-1024/headings/h6.1024` | Nunito Sans Bold | 10 | 20px | 0px | UPPER |
| `escala-1024/headings/bold-2014/h1.1024` | Nunito Sans Bold | 18 | 24px | 0px | ORIGINAL |
| `escala-1024/headings/bold-2014/h2.1024` | Nunito Sans Bold | 16 | 24px | 0px | ORIGINAL |
| `escala-1024/headings/bold-2014/h3.1024` | Nunito Sans Bold | 14 | 24px | 0px | ORIGINAL |
| `escala-1024/body/p.1024` | Nunito Sans Regular | 14 | 24px | 0px | ORIGINAL |
| `escala-1024/body/p.bold.1024` | Nunito Sans Bold | 14 | 24px | 0px | ORIGINAL |

## Sombras y Efectos (Effect Styles)

| Token | Efectos |
|---|---|
| `shadow/min` | Drop shadow: offset (0,0), blur 1, spread 0, rgba(0,36,100,0.10) |
| `shadow/controls` | Drop shadow: (0,2) blur 4 rgba(42,52,61,0.24) + (0,0) blur 2 rgba(42,52,61,0.12) |
| `shadow/tiny` | Drop shadow: (0,0) blur 1 rgba(131,147,163,1) |
| `shadow/neutral` | Drop shadow: (0,4) blur 12 rgba(42,52,61,0.10) |
| `shadow/none` | Drop shadow: none |
| `shadow/_dropshadowbig` | Drop shadow: (0,4) blur 42 spread 20 rgba(7,20,32,0.10) |

## Grillas (Grid Styles)

| Token | Config |
|---|---|
| `desktop-bootstrap (XL)` | Columns 12, gutter 32, section 63, align CENTER |
| `desktop-boostrap (LG)` | Columns 12, gutter 32, section 48, align CENTER |
| `tablet-boostrap (MD)` | Columns 6, gutter 32, section 88, align CENTER |
| `mobile-margins (XS -SM)` | Columns 4, gutter 32, offset 16, align STRETCH |

## Espaciado (Spacing system)

Spacing values follow a consistent incremental scale used across:
- Margins
- Padding
- Gaps
- Section spacing
- Component spacing

| Token | Value |
|---|---|
| spacing-0 | 0 |
| spacing-1 | 4 |
| spacing-2 | 8 |
| spacing-3 | 12 |
| spacing-4 | 16 |
| spacing-5 | 24 |
| spacing-6 | 32 |
| spacing-7 | 40 |

---

### Rules

- Small components use lower spacing values
- Large sections use higher spacing values
- Repeated spacing improves visual consistency
- Never use arbitrary spacing values outside the scale

## Densidad (Density Rules)

The system supports adaptive density levels according to workflow complexity and information volume.

| Density | Usage |
|---|---|
| Default | Standard readable interfaces |
| High | Data-heavy workflows and forms |

---

### Rules

- High density reduces vertical spacing
- Tables and large forms may use high density
- Critical actions must preserve accessible sizing
- Tooltips, alerts, and overlays should not use high density

## Responsive Rules

- Desktop layouts use 12-column grid
- Tablet layouts use 6-column grid
- Mobile layouts use 4-column grid
- Forms should progressively reduce columns on smaller screens
- Dense layouts may simplify on mobile devices

# Implementation Rules

This section defines how design tokens must be applied in code.

---

## Color Mapping (CSS / Angular)

All Paint Styles MUST be used as CSS variables or SCSS tokens.

Example mapping:

- `primary/@base` → var(--bch-primary-base)
- `gray/@dark` → var(--bch-gray-dark)
- `auxiliar/error/@base` → var(--bch-error-base)

DO NOT use raw HEX values in code.

---

## Semantic Usage Rules

- Success colors only represent positive states
- Error colors only represent destructive or invalid states
- Warning colors indicate caution
- Primary colors indicate actionable emphasis
- Neutral colors support secondary content

---

## Semantic Color Usage

| Semantic Role | Token |
|---|---|
| Primary Action | primary/@base |
| Error State | auxiliar/error/@base |
| Disabled Border | gray/@lighter |
| Surface Background | white/@white |
| Overlay Background | Overlay/Dark |

---

## Typography Usage

Text Styles map to CSS classes:

| Figma Token | CSS Class |
|---|---|
| `headings/h1` | .bch-h1 |
| `headings/h2` | .bch-h2 |
| `body/p` | .bch-body |
| `button/BUTTON` | .bch-button |

All typography MUST use these classes.

---

## Shadow Usage

Effect styles map to CSS classes:

- `shadow/neutral` → .bch-shadow-neutral
- `shadow/controls` → .bch-shadow-controls

---

## Grid System

Follow Bootstrap-based layout defined in Figma:

- Desktop: 12 columns
- Tablet: 6 columns
- Mobile: 4 columns

Use Angular Flex/Grid only aligned to this system.

---

## UI Rules

- Never hardcode spacing values
- Never create new colors
- Never create new typography rules
- Never override design system unless explicitly allowed

---

## Component Mapping

Standard UI components MUST follow design system rules:

- Buttons → use `button/BUTTON`
- Inputs → use body + gray tokens
- Cards → use `shadow/neutral` + `gray/@background`

## State Mapping Rules

Interactive components must visually map:
- System states
- Validation states
- Interaction states
- Value states

State priority must follow:
1. disabled
2. loading
3. error
4. success
5. interaction
6. value

