# Application Layout Rules

## Screen Structure

All application screens must follow a consistent hierarchical structure.

### Required Order

1. Header
2. Workflow / Progress Section
3. Main Content
4. Section Actions
5. Global Actions

---

### Header

Must contain:
- Primary navigation
- Screen title
- Global actions

---

### Workflow Section

Used for:
- Step indication
- Flow progress
- Current operation context

Must include:
- Flow title
- Step indicator
- Current step title

---

## Workflow Rules

Multi-step processes should:
- Display current step
- Display total step count
- Preserve visual continuity
- Maintain stable navigation placement
- Keep workflow context visible across steps

---

## Form Layout Rules

- Maximum 3 inputs per row
- Inputs within the same row must share width proportions
- Labels must remain visible at all times
- Related fields should remain visually grouped
- Dense forms should preserve alignment consistency
- Validation spacing must remain stable

---

## Section Composition Rules

Sections should follow a consistent internal hierarchy:

1. Section title
2. Section content
3. Section actions

Section content may contain:
- Form controls
- Tables
- Informational blocks
- Nested grouped elements

Actions should remain visually separated from content.

---

## Action Placement Rules

- Primary actions should appear at the bottom-right
- Secondary actions should remain visually grouped with primary actions
- Section-level actions may include:
  - Add
  - Edit
  - Delete
- Inline table actions should remain aligned consistently
- Actions must preserve positional stability

---

## Modal Usage Rules

Use modals for:
- Create operations
- Edit operations
- Focused confirmation flows

Avoid:
- Overloading primary screens
- Deep nested modal flows

Modals should include:
- Primary action
- Secondary action
- Explicit close behavior

---

## Action Herarchy Rules

- Only one primary action should exist per section
- Secondary actions should support the primary flow
- Primary actions should appear at the bottom-right
- Destructive actions should remain visually separated

---

## Validation Rules

---

## Density and Layout Rules

- Interfaces may be dense but must remain organized
- Alignment and repetition should drive visual structure
- Spacing should reinforce hierarchy
- Grouped content should remain visually cohesive
- Layouts should avoid unnecessary fragmentation

---

## Responsive Rules

---

## Consistency Principles

- All screens must follow the same structural hierarchy
- Navigation behavior must remain predictable
- Actions should preserve placement consistency
- Form layouts should preserve alignment patterns
- Similar workflows should reuse the same interaction patterns
