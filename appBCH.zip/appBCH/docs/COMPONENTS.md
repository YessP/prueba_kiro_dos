# UI Components System
This document defines behavioral rules, structure, states and constraints of UI components.
Visual definitions (colors, typography, spacing, shadows, focus styles) are defined in design.md

# 1. Shared Component Rules

## Appearance System

Shared contextual appearance model used across interactive components.

Applies to:
- Buttons
- Form Controls
- Navigation Components
- Feedback Components

| Appearance | Usage |
|---|---|
| default | Standard light surfaces |
| inverse | Dark or reversed surfaces |

---

## Icon System
Applies to Button and ButtonLink.

| Icon | Usage |
|---|---|
| none | No icon |
| left | Icon before label |
| right | Icon after label |

---

## Shared State Priority Model

All interactive components follow the same state priority hierarchy:

1. System State
2. Interaction State
3. Value State

Higher-priority states visually override lower-priority states.

---

# 2. Shared UX Rules
- Primary actions must remain visually distinguishable
- Avoid mixing navigation and action behaviors
- Components should preserve positional consistency across states
- Interactive areas must preserve accessible sizing

---

# 3. Shared Accessibility Rules

- All interactive elements must support keyboard navigation
- Focus state is mandatory
- Icon-only buttons must have aria-label
- Form controls must have associated labels

# 4. Action System (Buttons)
Components used to trigger actions, navigation or system events.
---

## Button

### Description
Primary interactive component used to trigger an action.

### Variants

| Variant | Usage |
|---|---|
| Primary | Main action in a screen |
| Secondary | Alternative action |
| Tertiary | Contextual or optional action |
| Neutral | Low emphasis action |
| Error | Destructive or critical action |

---

### Appearance (Context / Tone)

| Appearance | Usage |
|---|---|
| default | Standard surfaces (light backgrounds) |
| inverse | Dark backgrounds or reversed surfaces |

---

### Icon (Shared behavior)

Applies to: Button, ButtonLink

| Icon | Usage |
|---|---|
| none | No icon |
| left | Icon before label |
| right | Icon after label |

---

### State Model

#### 1. Value State
(Button does not have intrinsic value state)

---

#### 2. Interaction State
| State | Description |
|---|---|
| hover | Mouse over |
| pressed | Active interaction |
| focus | Keyboard focus |

---

#### 3. System State
| State | Description |
|---|---|
| disabled | Non-interactive |
| loading | Action in progress. Replace label and icon with spinner while preserving width |

---

### State Priority
1. disabled
2. loading  
3. interaction states  

---

### Rules
- Must always have a text label
- Must support keyboard interaction
- Must preserve layout consistency during loading state
- Must not be used for navigation (use ButtonLink instead)

---

## IconButton (Specialized Component)

### Description
Action button represented only by an icon. Used for compact or toolbar-based interactions.

---

### Variants

Same semantic variants as Button.

---

### State Model

Same as Button (without icon/text composition layer)

---

### Rules

- Must NOT contain text label
- Must always include `aria-label`
- Should not be used for navigation

---

## ButtonLink (Navigation Component)

### Description
Interactive element used exclusively for navigation.

---

### Variants

| Variant | Usage |
|---|---|
| Primary | Main action in a screen |
| Neutral | Low emphasis actions |
| Error | Destructive or critical actions |

> Secondary and Tertiary are not used in navigation context

---

### State Model

- Interaction states only
- System states (disabled only)

---

### Icon (Shared behavior)

Applies to: Button, ButtonLink

| Icon | Usage |
|---|---|
| none | Text-only link button |
| left | Icon before label |
| right | Icon after label |

---

### Rules

- Must be used only for navigation (routes or external links)
- Must NOT trigger data mutations or side effects
- Must render as anchor or router-link element
- Must include accessible label
- Must not behave as a form submission trigger

---

### Accessibility

- Must use semantic HTML (`a` or router-link)
- Must have meaningful label

---

# 5. Form Controls System
Components used to capture user input and state.

---

## Checkbox

### Description
Selection control used to allow users to select one, multiple, or partial options from a group.

Checkboxes support independent selection states and may be presented as standalone controls or embedded within cards.

---

### Variants

| Variant | Usage |
|---|---|
| Default | Standard checkbox control |
| Card | Checkbox integrated inside selectable container |

---

### Label Composition

| Label Type | Usage |
|---|---|
| none | Standalone checkbox |
| single-line | Simple label |
| multi-line | Label with supporting text |

---

### Supporting Content
- Helper text
- Tags
- Metadata

---

### State Model

#### 1. Value State (selection state)
| State | Description |
|---|---|
| checked | Selected |
| unchecked | Not selected |
| indeterminate  | Partial selection |

---

#### 2. Interaction State
| State | Description |
|---|---|
| hover | Mouse hover |
| focus | Keyboard focus |
| pressed | Active interaction |

---

#### 3. System State
| State | Description |
|---|---|
| disabled | Non-interactive |

---

### State Priority
1. disabled  
2. loading  
3. interaction states  
4. value state  

---

### Behavior

- Checkboxes allow independent selection
- Multiple checkboxes may be selected simultaneously
- Selecting the checkbox toggles its value state
- Indeterminate state represents partial group selection
- Labels and supporting content should remain associated with the control
- Disabled checkboxes preserve visible value state without interaction

---

### Accessibility

- Checkboxes must have associated labels
- Focus state must remain visually distinguishable
- Selection state must not rely exclusively on color
- Keyboard interaction must support Tab + Space
- Screen readers should announce checkbox state

---

### Composition Rules

- Use checkboxes for independent or multi-select choices
- Do not use checkboxes for mutually exclusive selection
- Related checkbox groups should remain visually grouped
- Supporting content should remain secondary to the primary label
- Card variants should preserve spacing consistency

---

### AI Interpretation Rules

- Use checkboxes for independent or multi-select choices
- Preserve spacing consistency between control and supporting content
- Card variants should maintain full-surface interaction
- Indeterminate state should communicate partial selection clearly
- Multiple checkbox selections may coexist simultaneously
- Avoid using checkboxes for binary settings or navigation behavior

---

## Radio

### Description
Selection control used to allow users to choose a single option within a mutually exclusive group.

Only one radio option may be selected at a time.

Radio controls may appear as standalone options or embedded inside selectable cards.

---

### Variants

| Variant | Usage |
|---|---|
| Default | Standard radio control |
| Card | Radio integrated inside selectable container |

---

### Label Composition

| Type | Usage |
|---|---|
| none | Standalone radio |
| single-line | Simple label |
| multi-line | Label with supporting text |

---

### Supporting Content

Optional supporting content may include:
- Helper text
- Metadata
- Contextual information

---

### State Model

#### 1. Value State (selection state)
| State | Description |
|---|---|
| selected | Active option |
| unselected | Inactive option |

---

#### 2. Interaction State
| State | Description |
|---|---|
| hover | Mouse hover |
| pressed | Active interaction |
| focus | Keyboard focus |

---

### System State
| State | Description |
|---|---|
| disabled | Non-interactive |
| readonly | Visible state without modification |

---

### Behavior

- Only one radio may be selected within the same group
- Selecting a radio automatically deselects sibling options
- Radio controls cannot be unselected directly once selected
- Labels and supporting content remain associated with the control
- Disabled radios preserve visible selection state without interaction
- Keyboard navigation should move sequentially through radio options

---

### Accessibility

- Radio controls must belong to a semantic radio group
- Each option requires an associated label
- Focus state must remain visually distinguishable
- Selected state must not rely exclusively on color
- Keyboard navigation must support arrow-key selection behavior

---

### Composition Rules

- Radio groups should contain related mutually exclusive options only
- Card variants should preserve spacing consistency
- Supporting content should remain secondary to the main label
- Large radio groups should preserve readable vertical spacing

---

### AI Interpretation Rules

- Treat radio groups as mutually exclusive selections
- Preserve consistent spacing and alignment between options
- Selection state should remain visually persistent
- Avoid mixing radio controls with multi-select behavior

---

## Switch

### Description
Binary toggle control used to enable or disable a specific setting or option.

Switches represent persistent state changes and provide immediate visual feedback.

---

### Variants

| Variant | Usage |
|---|---|
| Default | Standard switch control |
| Card | Switch integrated inside selectable container |

---

### Label Composition

| Type | Usage |
|---|---|
| none | Standalone switch |
| single-line | Main label only |
| multi-line | Label with supporting detail |

---

### Supporting Content

Optional supporting content may include:
- Detail text
- Helper text
- Metadata (tag)

---

### State Model

#### 1. Value State (toggle state)
| State | Description |
|---|---|
| on | active state |
| off | inactive state |

---

#### 2. Interaction State
| State | Description |
|---|---|
| hover | Mouse hover |
| pressed | Active interaction |
| focus | Keyboard focus |

---

#### 3. System State
| State | Description |
|---|---|
| disabled | Non-interactive |

---

### Behavior

- Switches toggle between ON and OFF states
- Changes apply immediately without additional confirmation
- The component must not trigger navigation or open overlays
- Disabled switches preserve visible state without interaction
- Labels and supporting content remain associated with the switch

---

### Accessibility

- Switches must have an associated label describing the setting
- Focus state must remain visually distinguishable
- State must not rely exclusively on color
- Keyboard interaction must support Tab + Space / Enter
- Screen readers should announce current switch state

---

### Composition Rules

- Use switches only for binary, persistent settings
- Do not use switches for multi-option selection
- Do not use switches for navigation behavior
- Supporting content should remain secondary to the primary label
- Card variants should preserve spacing consistency

---

### AI Interpretation Rules

- Use switches only for binary persistent settings
- Preserve spacing consistency between label, detail, and control
- ON state must clearly communicate active status
- OFF state must clearly communicate inactive status
- Avoid using switches for selection groups or navigation flows

## TextInput

### Description
Single-line text input control for free-form or constrained user input.

Supports decorators, validation feedback, prefixes, suffixes, and icon compositions.

---

### Variants

| Variant | Usage |
|---|---|
| Default | Standard text input |
| Password | Concealed text entry |
| Search | Search-oriented input |
| Country Phone | Country selector with phone input |
| Prefix/Suffix | Input with contextual values attached |

---

### Supported Configurations

- Leading icon
- Trailing icon
- Double icon
- Prefix
- Suffix
- Helper text
- Validation message
- Password visibility toggle
- Search action
- Country selector
- Character counter

---

### Anatomy

| Element | Description |
|---|---|
| label | Input descriptor |
| input field | Editable content area |
| placeholder | Optional hint text |
| helper text | Additional contextual guidance |
| validation message | Error or success feedback |
| leading icon | Optional icon before content |
| trailing icon | Optional icon after content |
| prefix | Static contextual value before content |
| suffix | Static contextual value after content |
| country selector | Country code selector |
| password toggle | Visibility action for password fields |
| search trigger | Search-related action |

---

### State Model

#### 1. Value State
| State | Description |
|---|---|
| empty | Field contains no value |
| filled | Field contains a value |

---

#### 2. Interaction State
Represents direct user interaction with the component.

| State | Description |
|---|---|
| hover | Pointer over component |
| pressed | Active press interaction |
| focus | Active keyboard focus |

---

### 3. System State
Represents availability or system-controlled behavior.

| State | Description |
|---|---|
| disabled | Field is unavailable and non-interactive |
| readonly | Field content is visible but cannot be edited |
| loading | Field is waiting for asynchronous data or validation |

---

### 4. Validation State
Represents validation feedback and input status.

| State | Description |
|---|---|
| default | No validation feedback displayed |
| error | Input contains invalid or incomplete data |
| success | Input is valid and confirmed |

---

### Behavior

- Labels remain visible at all times
- Placeholder text disappears once content is entered
- Validation feedback appears below the field
- Error state overrides interaction visual states
- Disabled inputs preserve visible content without interaction
- Readonly inputs allow text selection without modification
- Password variants allow visibility toggling
- Search variants may trigger immediate or manual search behavior
- Prefixes and suffixes remain fixed and non-editable
- Country phone variants synchronize selector and input value

---

### Optional Features
| Feature | Description |
|---|---|
| clear button | Removes current input value |
| password visibility toggle | Shows or hides password content |
| input masking | Restricts formatting (e.g. phone, date) |
| autocomplete | Suggests previously entered values |
| character limit | Restricts maximum number of characters |

---

### Accessibility

- Inputs must have associated labels
- Focus state must remain visually distinguishable
- Validation feedback must not rely exclusively on color
- Error messages should be announced to assistive technologies
- Password visibility actions require accessible labels
- Placeholder text must not replace labels
- Keyboard navigation must support all interactive decorators

---

### Composition Rules

- Inputs should align consistently inside grid layouts
- Labels should remain positioned above the field
- Helper text and validation messages should remain visually secondary
- Prefixes and suffixes should not replace labels
- Decorative icons must not interfere with content readability
- Search inputs should preserve compact interaction behavior
- Country selector width should remain visually stable

---

### AI Interpretation Rules

- Preserve label visibility at all times
- Maintain consistent spacing between label, field, and helper content
- Error state should remain visually dominant
- Inverse appearance must preserve accessibility contrast
- Prefixes and suffixes are contextual decorators, not editable values
- Password fields require visibility toggle behavior
- Search fields should visually communicate search interaction
- Country phone inputs should preserve aligned composite layout

---

## SelectInput

### Description
Selection input control used to choose one or multiple predefined options from a dropdown list.

Supports searchable lists, country selectors, checkbox selection, and contextual option rendering.

---

### Variants

| Variant | Usage |
|---|---|
| Default | Standard dropdown selection |
| Searchable | Dropdown with searchable options |
| Country Select | Dropdown with country metadata |
| MultiSelect | Multiple selectable options |
| Checkbox List | Multi-select using checkboxes |

---

### Supported Configurations

- Searchable list
- Leading icon
- Country flag
- Checkbox options
- Multi-select
- Async loading
- Helper text
- Validation message

---

### Anatomy

| Element | Description |
|---|---|
| label | Field descriptor |
| selected value | Current selected option |
| placeholder | Optional empty-state hint |
| dropdown trigger | Opens option list |
| option list | Selectable options container |
| option item | Individual selectable row |
| helper text | Additional contextual guidance |
| validation message | Error or success feedback |
| search field | Search/filter input |
| checkbox option | Multi-select option control |
| country metadata | Flag or country identifier |

---

### State Model

#### 1. Value State
| State | Description |
|---|---|
| empty | No selection |
| selected | Value selected |
| multiple | Multiple values selected |

---

#### 2. Interaction State
| State | Description |
|---|---|
| hover | Mouse hover |
| pressed | Active interaction |
| focus | Keyboard focus |
| expanded | Dropdown list visible |

---

#### 3. System State
| State | Description |
|---|---|
| disabled | Non-interactive |
| readonly | Visible selection without modification |
| loading | Async state |

---

#### 4. Validation State

| State | Description |
|---|---|
| default | No validation feedback |
| success | Valid confirmed selection |
| error | Invalid or incomplete selection |

---

### Behavior

- Selecting an option updates the displayed value
- Expanded state displays available selectable options
- Searchable variants filter visible options dynamically
- Multi-select variants preserve multiple selected values
- Checkbox variants allow independent option selection
- Country select variants display contextual country metadata
- Validation feedback appears below the field
- Disabled fields preserve visible value without interaction
- Readonly fields display value without allowing changes
- Dropdown closes after selection unless multi-select behavior is enabled

---

### Accessibility

- Select inputs must have associated labels
- Focus state must remain visually distinguishable
- Keyboard navigation must support:
  - Tab
  - Arrow keys
  - Enter
  - Escape
- Expanded state must be announced to assistive technologies
- Validation feedback must not rely exclusively on color
- Option lists should preserve semantic list behavior

---

### Composition Rules

- Option lists should preserve consistent spacing and alignment
- Country metadata should remain visually secondary to labels
- Multi-select variants should preserve readable selected states
- Checkbox lists should maintain aligned control spacing
- Helper text and validation messages should remain secondary
- Long option lists should support scrolling behavior

---

### AI Interpretation Rules

- Treat SelectInput as a selection control, not free text entry
- Preserve label visibility at all times
- Expanded state must visually communicate active selection mode
- Multi-select variants should preserve readable selected values
- Country variants should maintain aligned metadata presentation
- Checkbox variants should communicate independent option selection
- Validation feedback should remain visually persistent
- Dropdown positioning should avoid overlapping critical content

---

## TextArea

### Description
Multi-line text input control used for long-form or extended textual content.

Supports validation feedback, character counters, resizing behavior, and contextual helper content.

---

### Variants

| Variant | Usage |
|---|---|
| Default | Standard multi-line text area |
| Auto Resize | Dynamically grows with content |
| Fixed Height | Scrollable content within fixed area |
| Counter | Displays character count |

---

### Supported Configurations

- Auto resize
- Fixed height
- Character counter
- Helper text
- Validation message
- Max length
- Scroll behavior

---

### Anatomy

| Element | Description |
|---|---|
| label | Field descriptor |
| textarea field | Editable multi-line content area |
| placeholder | Optional hint text |
| helper text | Additional contextual guidance |
| validation message | Error or success feedback |
| counter | Character usage indicator |
| resize handle | Optional resize interaction |

---

### State Model

#### 1. Value State

| State | Description |
|---|---|
| empty | Field contains no value |
| filled | Field contains content |

---

#### 2. Interaction State

| State | Description |
|---|---|
| hover | Pointer over component |
| focus | Active keyboard focus |
| pressed | Active interaction |
| scrolling | Internal content scrolling |

---

#### 3. System State

| State | Description |
|---|---|
| disabled | Non-interactive field |
| readonly | Content visible but not editable |

---

#### 4. Validation State

| State | Description |
|---|---|
| default | No validation feedback |
| success | Valid confirmed content |
| error | Invalid or incomplete content |

---

### Behavior

- Labels remain visible at all times
- Placeholder text disappears once content is entered
- Validation feedback appears below the field
- Auto resize variants expand vertically with content
- Fixed height variants enable internal scrolling
- Character counters update dynamically during typing
- Disabled fields preserve visible content without interaction
- Readonly fields allow text selection without modification
- Error state overrides interaction visual states

---

### Accessibility

- Textareas must have associated labels
- Focus state must remain visually distinguishable
- Validation feedback must not rely exclusively on color
- Error messages should be announced to assistive technologies
- Character counters should remain readable and non-intrusive
- Keyboard navigation must preserve natural text editing behavior

---

### Composition Rules

- Textareas should align consistently within form layouts
- Labels should remain positioned above the field
- Helper text and validation messages should remain visually secondary
- Auto resize behavior should preserve layout stability
- Long-form content should remain readable without excessive density
- Counters should remain aligned to the lower edge of the component

---

### AI Interpretation Rules

- Preserve label visibility at all times
- Maintain consistent spacing between label, field, helper content, and counter
- Error state should remain visually dominant
- Auto resize behavior should expand vertically only
- Fixed height variants should preserve internal scroll behavior
- Counters should remain visually secondary
- Long-form content should preserve readability and spacing consistency

---

## NumberInput

### Description

Numeric input control used to increase, decrease, or manually enter quantitative values.

Supports stepper controls, min/max constraints, validation feedback, and continuous increment behavior.

---

### Variants

| Variant | Usage |
|---|---|
| Default | Standard numeric stepper input |
| Compact | Reduced visual footprint |
| Inline | Embedded numeric control inside compact layouts |

---

### Supported Configurations

- Increment control
- Decrement control
- Min/max values
- Step intervals
- Helper text
- Validation message

---

### Anatomy

| Element | Description |
|---|---|
| label | Field descriptor |
| input field | Numeric editable value |
| decrement control | Reduces numeric value |
| increment control | Increases numeric value |
| helper text | Additional contextual guidance |
| validation message | Error or success feedback |

---

### State Model

#### 1. Value State

| State | Description |
|---|---|
| empty | No numeric value |
| filled | Numeric value present |
| min | Minimum allowed value reached |
| max | Maximum allowed value reached |

---

#### 2. Interaction State

| State | Description |
|---|---|
| hover | Pointer over component |
| focus | Active keyboard focus |
| pressed | Active interaction |
| holding | Continuous increment/decrement interaction |

---

#### 3. System State

| State | Description |
|---|---|
| disabled | Non-interactive field |
| readonly | Value visible but not editable |

---

#### 4. Validation State

| State | Description |
|---|---|
| default | No validation feedback |
| success | Valid confirmed value |
| error | Invalid or restricted value |

---

### Behavior

- Increment control increases the current value
- Decrement control decreases the current value
- Values must respect configured min/max constraints
- Disabled fields preserve visible value without interaction
- Readonly fields allow value visibility without modification
- Validation feedback appears below the field
- Error state overrides interaction visual states

---

### Accessibility

- Number inputs must have associated labels
- Focus state must remain visually distinguishable
- Increment and decrement controls must support keyboard interaction
- Validation feedback must not rely exclusively on color
- Screen readers should announce current numeric value
- Min/max restrictions should be communicated accessibly

---

### Composition Rules

- Increment and decrement controls should remain visually balanced
- Numeric values should remain centered and readable
- Compact variants should preserve minimum touch target sizes
- Validation and helper text should remain visually secondary
- Stepper controls should preserve consistent spacing alignment

---

### AI Interpretation Rules

- Treat NumberInput as a quantitative control, not free-form text input
- Preserve alignment consistency between controls and value
- Increment and decrement actions should remain visually explicit
- Compact variants should preserve accessibility and readability
- Validation feedback should remain visually persistent
- Numeric values should remain visually prioritized within the component

---

## SegmentedInput

### Description
Grouped input control composed of multiple segmented fields representing a single structured value.

Used for verification codes, security codes, PINs, OTP flows, and segmented numeric entry.

---

### Variants

| Variant | Usage |
|---|---|
| Code | Sequential verification or OTP input |
| Card Code | Structured grouped numeric entry |
| Compact | Reduced-width segmented layout |

---

### Supported Configurations

- Fixed segment count
- Auto focus advance
- Auto backspace navigation
- Paste distribution
- Secure masking
- Helper text
- Validation message

---

### Anatomy

| Element | Description |
|---|---|
| label | Field descriptor |
| segment field | Individual input unit |
| grouped value | Combined structured value |
| helper text | Additional contextual guidance |
| validation message | Error or success feedback |

---

### State Model

#### 1. Value State

| State | Description |
|---|---|
| empty | No value entered |
| partial | Incomplete segmented value |
| completed | All segments completed |

---

#### 2. Interaction State

| State | Description |
|---|---|
| hover | Pointer over segment |
| focus | Active segment focus |
| pressed | Active interaction |
| typing | User entering segmented content |

---

#### 3. System State

| State | Description |
|---|---|
| disabled | Non-interactive segmented input |
| readonly | Value visible but not editable |

---

#### 4. Validation State

| State | Description |
|---|---|
| default | No validation feedback |
| success | Valid completed value |
| error | Invalid or incomplete value |

---

### Behavior

- Each segment represents part of a single structured value
- Entering content automatically advances focus to the next segment
- Backspace navigation returns focus to previous segments when empty
- Paste operations distribute content sequentially across segments
- Completed state requires all segments to contain valid values
- Validation feedback appears below the grouped component
- Disabled segments preserve visible values without interaction
- Readonly segments allow visibility without modification
- Error state overrides interaction visual states

---

### Accessibility

- Segmented inputs must have associated labels
- Focus state must remain visually distinguishable
- Keyboard navigation must preserve sequential flow
- Validation feedback must not rely exclusively on color
- Screen readers should communicate grouped input context
- Segment order should remain logically announced

---

### Composition Rules

- Segment spacing should remain visually consistent
- All segments should preserve equal sizing
- Labels should remain positioned above grouped segments
- Helper text and validation messages should remain visually secondary
- Compact variants should preserve readability and touch accessibility
- Grouped values should visually communicate a single combined input

---

### AI Interpretation Rules

- Treat SegmentedInput as a single structured value
- Preserve equal segment sizing and spacing
- Maintain sequential keyboard interaction flow
- Completed state should communicate full valid entry
- Validation feedback should remain visually persistent
- Avoid mixing segmented layouts with unrelated controls

---

## DatePicker

### Description
Interactive date selection component based exclusively on visual calendar selection.

---

### Variants

| Variant | Usage |
|---|---|
| Single | Select one date |
| Range | Select start and end dates |
| Month | Select month only |
| Year | Select year only |

---

### State Model

#### 1. Value State
| State | Description |
|---|---|
| empty | No value selected |
| selected | Valid value selected |
| range-start | Initial range date |
| range-end | Final range date |
| in-range | Intermediate range preview |

---

#### 2. Interaction State
| State | Description |
|---|---|
| hover | Pointer over selectable item |
| pressed | Active interaction |
| focus | Keyboard focus visible |

---

#### 3. System State
| State | Description |
|---|---|
| disabled | Non-interactive |
| readonly | Selection allowed without typing |

#### 4. Validation State
| State | Description |
|---|---|
| error | Validation error |


---

# 6. Navigation System
Components used to navigate, organize, filter, or switch between content views.

---

## Tabs

### Description
Navigation component used to switch between related views, sections, or content panels within the same context.

Only one tab can be active at a time.

Tabs preserve the current page context and do not trigger full page navigation.

---

### Anatomy
| Element | Description |
|---|---|
| Tab Group | Container for tab items |
| Tab Item | Interactive selectable item |
| Label | Main tab text |
| Supporting Text | Optional secondary text |
| Active Indicator | Visual selection line |
| Content panel | Associated content section |

---

### Variants

| Variant | Usage |
|---|---|
| Single | Independent tab item |
| Group | Multiple related tab items |

---

### State Model

#### 1. Value State
| State | Description |
|---|---|
| active | Current selected tab |
| inactive | Non-selected tab |

---

#### 2. Interaction State
| State | Description |
|---|---|
| hover | Pointer over tab |
| pressed | Active click interaction |
| focus | Keyboard focus |

---

#### 3. System State
| State | Description |
|---|---|
| enabled | Interactive state |
| disabled | Non-interactive state |

---

### Behavior Rules
- Only one tab may be active at a time.
- Changing tabs updates the associated content panel.
- Tab selection must preserve layout stability
- Disabled tabs cannot be selected
- Horizontal overflow may become scrollable

---

## Pills

### Description
Compact segmented selection component used for filtering, subcategories, or lightweight contextual navigation.

---

### Anatomy
| Element | Description |
|---|---|
| Pill Group | Container for pills |
| Pill Item | Interactive selectable segment |
| Label | Visible option text |
| Active Background | Selected visual state |
| Content panel | Associated content section |

---

### Variants

| Variant | Usage |
|---|---|
| Single | Independent pill |
| Group | Multiple segmented pills |

---

### State Model

#### 1. Value State
| State | Description |
|---|---|
| selected | Active pill |
| unselected | Inactive pill |

---

#### 2. Interaction State
| State | Description |
|---|---|
| hover | Pointer over pill |
| pressed | Active interaction |
| focus | Keyboard focus visible |

---

#### 3. System State
| State | Description |
|---|---|
| disabled | Non-interactive pill |

---

### Behavior Rules
- Only one pill may be selected at a time
- Selection updates associated content or filtering state
- Pills may adapt to content width
- Groups may scroll horizontally on overflow

---

## Paginator

### Description

Navigation component used to divide large collections of content into sequential pages.

---

### Variants

| Variant | Usage |
|---|---|
| Basic | Page navigation only |
| WithPageSize | Includes results-per-page selector |
| WithPageJump | Includes direct page navigation input |
| Mobile | Compact navigation layout |

---

### Anatomy

| Element | Description |
|---|---|
| Previous Button | Navigates to previous page |
| Next Button | Navigates to next page |
| Page Item | Individual page selector |
| Active Indicator | Current page state |
| Ellipsis | Collapsed page range |
| Page Size Selector | Results-per-page control |
| Page Jump Input | Direct page navigation |
| Results Summary | Current visible range information |

---

### State Model

#### 1. Value State

| State | Description |
|---|---|
| selected | Current active page |
| unselected | Inactive page item |

---

#### 2. Interaction State

| State | Description |
|---|---|
| hover | Pointer over item |
| pressed | Active interaction |
| focus | Keyboard focus visible |

---

#### 3. System State

| State | Description |
|---|---|
| disabled | Navigation unavailable |
| loading | Awaiting asynchronous data |

---

### Behavior

- Selecting a page updates visible content
- Previous and next buttons navigate sequentially
- Active page remains visually highlighted
- Ellipsis collapse excessive page ranges
- Results-per-page selector updates visible item count
- Page jump input navigates directly to a specific page
- Disabled navigation prevents invalid page transitions
- Mobile variants reduce visible page density

---

## ProgressStepper

### Description

Sequential progress navigation component used to communicate workflow progression across multiple steps.

Supports linear multi-step flows with progress indication and contextual navigation.

---

### Variants

| Variant | Usage |
|---|---|
| Desktop | Horizontal multi-step progress |
| Mobile | Compact responsive progress layout |

---

### Anatomy

| Element | Description |
|---|---|
| Progress Line | Visual workflow progression |
| Active Segment | Current completed progress |
| Step Indicator | Current step reference |
| Step Label | Current step title |
| Step Counter | Current step position |
| Previous Action | Back navigation |
| Next Action | Forward navigation |

---

### State Model

#### 1. Value State

| State | Description |
|---|---|
| pending | Step not reached |
| active | Current step |
| completed | Finished step |

---

#### 2. Interaction State

| State | Description |
|---|---|
| hover | Pointer over navigation action |
| pressed | Active interaction |
| focus | Keyboard focus visible |

---

#### 3. System State

| State | Description |
|---|---|
| disabled | Navigation unavailable |
| loading | Awaiting asynchronous progression |

---

### Behavior

- Progress updates sequentially between steps
- Current step remains visually highlighted
- Completed steps preserve visible progress indication
- Previous and next actions navigate workflow progression
- Mobile variants reduce visual density while preserving progression clarity
- Progress line updates proportionally according to current step
- Navigation availability depends on workflow constraints

---

# 7. Feedback & Overlay System
Components used to display metadata or categorized information.

---

## Chips

### Description 
Compact interactive component used to represent attributes, selections, filters, entities, or lightweight actions.

---

### Variants

| Variant | Usage |
|---|---|
| Default | Basic informational chip |
| Icon | Leading icon chip |
| Avatar | Image or avatar chip |
| Username | Username chip | 
| Currency | Card currency chip |

---

### Anatomy
| Element | Description |
|---|---|
| Container | Interactive chip surface |
| Label | Visible chip text |
| Leading Element | Optional icon/avatar/check |
| Trailing Element | Optional dismiss action |
| Preffix | Static value before content |     

---

### State Model

#### 1. Value State (toggle state)
| State | Description |
|---|---|
| selected | Active chip |
| unselected | Inactive chip |

---

#### 2. Interaction State
| State | Description |
|---|---|
| hover | Pointer over chip |
| pressed | Active interaction |
| focus | Keyboard focus visible |

---

#### 3. System State
| State | Description |
|---|---|
| disabled | Non-interactive chip |

---

### Behavior rules
- Chips may be interactive or informational
- Chips may represent filters, selections, tags, or entities
- Chips may include optional leading icons, avatars, or selection indicators
- Chips may include optional dismiss actions
- Selection state updates visually on interaction
- Removal actions should preserve layout stability
- Chip groups may wrap across multiple lines
- Overflow behavior should preserve readability and spacing consistency

---

### AI Interpretation Rules

- Preserve stable sizing across states
- Close actions must remain independently interactive
- Use reusable composition structure for icon/avatar/check variants

---

## Tags

### Description

Non-interactive labeling component used to communicate status, categorization, metadata, counters, or contextual information.
Tags are informational only and do not trigger actions.

---

### Variants

| Variant | Usage |
|---|---|
| Success | Positive or completed states |
| Info | Informational states |
| Warning | Caution or attention states |
| Error | Critical or negative states |
| Neutral | Inactive or secondary information |
| Lock | Restricted or blocked states |
| Counter | Numeric indicators |
| New | New elements |
| Types | card type description |
| Discount | discount percentage |

---

### Anatomy

| Element | Description |
|---|---|
| Container | Tag surface |
| Label | Visible informational text |
| Leading Element | Optional icon or status indicator |
| Counter | Optional numeric value |

---

### State Model

#### 1. Value State
| State | Description |
|---|---|
| default | Standard informational state |

---

#### 2. Interaction State

- Tags are non-interactive

---

#### 3. System State
| State | Description |
|---|---|
| disabled | Reduced emphasis informational state |

---

### Behavior rules
- Tags are non-interactive
- Tags communicate status, categorization, or metadata
- Tags may include optional icons, dots, or counters
- Tags must preserve compact layout behavior
- Tag groups may wrap across multiple lines
- Overflow behavior should preserve readability and spacing consistency

---

## Tooltip

### Description

Contextual floating component used to provide supplemental information, guidance, or compact metadata associated with another element.

Tooltips are transient and appear on user interaction.

---

### Variants

| Variant | Usage |
|---|---|
| Default | Standard informational tooltip |
| Toaster | Extended informational message |
| SideNumber | Compact numeric indicator |

---

### Anatomy

| Element | Description |
|---|---|
| Container | Floating tooltip surface |
| Content | Informational text or value |
| Anchor | Associated trigger element |
| Arrow | Optional directional indicator |

---

### State Model

#### 1. Value State
| State | Description |
|---|---|
| hidden | Tooltip not visible |
| visible | Tooltip displayed |

---

#### 2. Interaction State
| State | Description |
|---|---|
| hover | Trigger hovered |
| focus | Trigger focused |

---

### Behavior rules

- Tooltips appear on hover or focus
- Tooltips are anchored to a related element
- Tooltips disappear when interaction ends
- Tooltips do not block surrounding layout
- Tooltip positioning adapts to available viewport space
- Long content should preserve readability without excessive width

---

## Modal

### Description

Overlay dialog component used to display contextual information, confirmations, warnings, or focused user actions without leaving the current screen.

Modals interrupt the current workflow and require explicit dismissal or completion.

---

### Variants

| Variant | Usage |
|---|---|
| Info | Informational contextual message |
| Success | Successful operation feedback |
| Warning | Cautionary or important confirmation |
| Error | Critical or blocking issue |
| Neutral | Generic contextual interaction |

---

### Supported Configurations

- Title
- Description
- Icon
- Primary action
- Secondary action
- Close action
- Dismissible overlay
- Centered layout

---

### Anatomy

| Element | Description |
|---|---|
| overlay | Background blocking layer |
| container | Modal surface |
| icon | Contextual status indicator |
| title | Primary modal heading |
| description | Supporting contextual content |
| actions | Primary and secondary actions |
| close action | Explicit dismissal control |

---

### State Model

#### 1. Interaction State

| State | Description |
|---|---|
| open | Modal visible |
| closing | Exit transition |
| focus | Active keyboard focus |

---

#### 2. System State

| State | Description |
|---|---|
| dismissible | Allows closing interaction |
| blocking | Prevents dismissal outside actions |

---

### Behavior

- Modals appear above all application content
- Background interaction becomes unavailable while modal is open
- Focus remains trapped within the modal surface
- Primary actions remain visually prioritized
- Closing the modal restores focus to the triggering element
- Overlay click closes dismissible variants only
- Escape key closes dismissible variants
- Error and warning variants require stronger visual emphasis

---

### Accessibility

- Modals must trap keyboard focus while open
- Initial focus should move into the modal automatically
- Escape key behavior must remain predictable
- Screen readers should announce modal opening
- Modal titles must remain semantically associated
- Background content should become inaccessible while open

---

## EmptyState

### Description

Feedback component used to communicate the absence of content, unavailable data, inactive states, errors, or recommended actions.

Empty states guide users toward the next available action or explain the current system status.

---

### Variants

| Variant | Usage |
|---|---|
| No Data | No available content or records |
| No Results | Empty search or filter result |
| Error | Failed operation or unavailable service |
| Warning | Temporary interruption or limitation |
| Recommendation | Suggested next action or product |
| Informational | Contextual guidance or onboarding |

---

### Supported Configurations

- Illustration
- Icon
- Title
- Description
- Primary action
- Secondary action
- Inline layout
- Fullscreen layout

---

### Anatomy

| Element | Description |
|---|---|
| illustration | Contextual visual representation |
| icon | Simplified state indicator |
| title | Primary message |
| description | Supporting contextual explanation |
| primary action | Main recovery or continuation action |
| secondary action | Optional alternative action |

---

### Layout Variants

| Variant | Usage |
|---|---|
| Inline | Embedded inside tables or sections |
| Card | Isolated informational container |
| Fullscreen | Primary empty application state |

---

### State Model

#### 1. Semantic State

| State | Description |
|---|---|
| informational | Neutral contextual message |
| success | Positive completion or recommendation |
| warning | Cautionary or temporary issue |
| error | Blocking or failed state |

---

### Behavior

- Empty states should clearly explain the current situation
- Primary actions should guide users toward recovery or continuation
- Illustrations remain supportive and secondary to content
- Inline variants adapt to parent container width
- Fullscreen variants remain visually centered
- Messages should remain concise and actionable
- Actions remain optional depending on context

---

### Composition Rules

- Title should remain visually prioritized
- Descriptions should remain concise
- Actions should remain limited and purposeful
- Illustrations should not overpower content
- Inline variants should preserve surrounding layout consistency
- Fullscreen variants should maintain centered alignment

---

# 8. Data Display System
Components that provide contextual information or feedback.

---

## Accordion

## Description
Expandable content container used to organize and progressively reveal related sections of information within the same page context.

Supports collapsing and expanding grouped content while preserving layout structure.

---

### Variants

| Variant | Usage |
|---|---|
| Default | Standard expandable section |
| Compact | Reduced spacing layout |
| FormSection | Accordion used inside forms and workflows |

---

### Anatomy

| Element | Description |
|---|---|
| Container | Accordion section wrapper |
| Header | Interactive expandable trigger |
| Title | Section label |
| Supporting Content | Optional contextual information |
| Expand Icon | Expansion state indicator |
| Content Panel | Expandable content container |
| Divider | Visual separation between sections |

---

### State Model

#### 1. Value State

| State | Description |
|---|---|
| expanded | Content visible |
| collapsed | Content hidden |

---

#### 2. Interaction State

| State | Description |
|---|---|
| hover | Pointer over header |
| pressed | Active interaction |
| focus | Keyboard focus visible |

---

#### 3. System State

| State | Description |
|---|---|
| disabled | Non-interactive accordion |
| readonly | Content visible without interaction |

---

## Behavior

- Headers toggle content visibility
- Expanded sections reveal associated content inline
- Collapse behavior preserves surrounding layout structure
- Expand indicators update according to visibility state
- Multiple sections may remain expanded simultaneously unless configured otherwise
- Form sections preserve field grouping and spacing consistency
- Collapsed sections hide content without removing section context

---

# 9. Layout System 

Structural layout primitives used to organize screens, workflows, forms, sections, and content hierarchy.

Layout components define:
- Page structure
- Alignment behavior
- Content grouping
- Responsive distribution
- Workflow hierarchy

Layout components are structural only and must not contain business logic.

---

## PageContainer

### Description
Primary application screen wrapper.

Defines:
- Maximum content width
- Horizontal margins
- Responsive behavior
- Vertical page flow

Used for:
- Main application screens
- Wizards
- Workflow pages

---

### Behavior

- Content remains centered within viewport
- Layout follows responsive grid system
- Internal sections preserve vertical rhythm
- Primary workflow content remains visually prioritized

---

## WorkflowContainer

### Description
Layout container used for multi-step workflows and wizard-based processes.

Used for:
- Step-by-step flows
- Financial operations
- Guided forms
- Sequential processes

---

### Anatomy

| Element | Description |
|---|---|
| Header Area | Workflow title and context |
| Progress Area | Stepper and progression |
| Content Area | Current workflow content |
| Action Area | Primary and secondary actions |

---

### Behavior

- Workflow progression remains visually persistent
- Current step context remains visible
- Navigation actions remain positionally stable
- Content updates without disrupting workflow hierarchy

---

## Section

### Description
Structural container used to group related content within workflows and forms.

Used for:
- Form grouping
- Financial blocks
- Related data sections
- Expandable content groups

---

### Variants

| Variant | Usage |
|---|---|
| Default | Standard grouped section |
| Accordion | Expandable section |
| Elevated | Visually emphasized section |

---

### Anatomy

| Element | Description |
|---|---|
| Header | Section title and contextual actions |
| Content | Grouped content area |
| Actions | Optional section-level actions |

---

### Behavior

- Sections preserve grouped hierarchy
- Internal spacing follows spacing system
- Related fields remain visually grouped
- Actions remain separated from content

---

## ContentGroup

### Description
Lightweight grouping container used to organize related controls or informational elements inside sections.

Used for:
- Input groups
- Inline related fields
- Radio groups
- Logical field clusters

---

### Behavior

- Related elements preserve visual association
- Internal spacing remains consistent
- Supports vertical and horizontal grouping

---

## Grid

### Description
Responsive column-based layout container used to distribute content horizontally.

Used for:
- Form layouts
- Multi-column content
- Dense enterprise workflows

---

### Variants

| Variant | Usage |
|---|---|
| 1-column | Mobile layouts |
| 2-column | Medium-density layouts |
| 3-column | Standard form layouts |

---

### Behavior

- Maximum 3 content columns per row
- Columns preserve proportional widths
- Layout adapts responsively across breakpoints
- Dense layouts preserve readability and alignment

---

## Stack

### Description
Vertical layout container used to distribute elements sequentially.

Used for:
- Form rows
- Section stacking
- Vertical action groups
- Content rhythm

---

### Behavior

- Elements stack vertically
- Spacing follows spacing scale
- Supports density adaptation

---

## Inline

### Description
Horizontal layout container used to align related elements in a row.

Used for:
- Action groups
- Inline controls
- Chips and tags
- Compact field layouts

---

### Behavior

- Elements align horizontally
- Wrapping may occur on smaller screens
- Alignment remains visually consistent

---

## Divider

### Description
Visual separator used to distinguish sections or grouped content.

Used for:
- Section separation
- Workflow grouping
- Dense layout organization

---

### Variants

| Variant | Usage |
|---|---|
| Horizontal | Standard separation |
| Vertical | Inline separation |

---

### Behavior

- Dividers preserve visual hierarchy
- Spacing around dividers follows layout rhythm
- Decorative only, without interaction

---

## Panel

### Description
Elevated or bordered container used to visually isolate content blocks.

Used for:
- Informational summaries
- Highlighted workflow areas
- Financial details
- Contextual blocks

---

### Variants

| Variant | Usage |
|---|---|
| Neutral | Standard informational block |
| Highlighted | Emphasized content |
| Informational | Contextual guidance |

---

### Behavior

- Panels visually separate content from surrounding layout
- Internal spacing follows spacing system
- Supports dense information layouts

---

## ActionBar

### Description
Layout container used to align primary and secondary actions.

Used for:
- Form actions
- Wizard navigation
- Section-level actions

---

### Behavior

- Primary actions align to the right
- Secondary actions remain grouped with primary actions
- Action placement remains stable across states
- Mobile layouts preserve accessible interaction spacing

---

## EmptyStateContainer

### Description
Layout container used for empty, loading, or no-result states.

Used for:
- Empty tables
- No search results
- Initial workflow states

---

### Behavior

- Content remains visually centered
- Messaging remains concise
- Actions remain visually prioritized
- Spacing preserves readability

---

## AI Interpretation Rules

- Use layout primitives before generating arbitrary containers
- Preserve consistent spacing rhythm
- Respect responsive grid behavior
- Avoid excessive nesting
- Preserve workflow hierarchy across screens
- Use Grid for form distribution
- Use Stack for vertical rhythm
- Use Inline for compact horizontal alignment