# MCP Tool Usage

Always use the OpenAI developer documentation MCP server if you need to work with the OpenAI API, ChatGPT Apps SDK, Codex, or OpenAI developer docs without me having to explicitly ask.

Use the Figma MCP server whenever I ask to create, modify, inspect, or export designs in Figma or FigJam.

When building or updating designs in Figma, always structure frames with nested Auto Layout by default unless I explicitly ask for a freeform exception.

---

# Design System (CRITICAL RULE)

The file `design.md` is the SINGLE SOURCE OF TRUTH for all UI/UX decisions.

You MUST:
- Use ONLY tokens defined in `design.md`
- Never invent colors, spacing, typography or shadows
- Always map UI to existing tokens first
- Prefer reuse of existing styles instead of custom styling

If something is not in `design.md`, ask before creating new styles.

---

# Design System Enforcement

You MUST interpret `design.md` as both:

1. Visual specification (Figma reference)
2. Technical implementation guide (Angular/CSS mapping)

Before generating any UI:
- Identify required tokens
- Map them to CSS classes or variables
- Never output raw styles
- Always use design system abstractions

---

# Angular Stack

- Use Angular 17+
- Use standalone components by default
- Use strict TypeScript typing
- Prefer Angular Signals when possible
- Use RxJS only when reactive streams are required
- Use Angular Material only if already aligned with design tokens

---

# UI / Design System Usage Rules

## Colors
- Use ONLY Paint Styles from `design.md`
- Example: `primary/@base`, `gray/@dark`, `auxiliar/error/@base`
- Never use HEX values directly in components

## Typography
- Use ONLY Text Styles from `design.md`
- Example: `headings/h1`, `body/p`, `button/BUTTON`
- Do not manually define font sizes, weights or line heights

## Spacing & Layout
- Follow grid rules defined in `design.md`
- Use 8px spacing logic implicitly based on system behavior
- Respect bootstrap grid definitions (desktop/tablet/mobile)

## Shadows & Effects
- Use only Effect Styles defined in `design.md`
- Example: `shadow/neutral`, `shadow/controls`

---

# Component Architecture

- Feature-based structure
- Separation of UI / logic / data
- Services handle business logic and API calls
- Components only handle presentation

Each component should include:
- .ts
- .html
- .scss
- service.ts (if needed)
- interface.ts (if needed)

---

# UI Development Rules

When generating UI:

1. Read `design.md` first
2. Identify matching tokens (color, typography, shadow, grid)
3. Build UI strictly using those tokens
4. Do NOT improvise styles
5. Ensure consistency with existing components

Before generating screens:
1. Use tokens from design.md
2. Use only components defined in components.md
3. Respect all composition rules from layout-rules.md
4. Preserve workflow consistency across screens

---

# Forms

- Use Reactive Forms only
- Use validation rules consistently
- Show error states using auxiliar/error tokens
- Follow typography rules from design system

---

# API Layer

- Use HttpClient
- Centralize endpoints in services
- Use interceptors for auth/session
- Avoid nested subscriptions

---

# Code Quality Rules

Always:

- Reuse existing components
- Follow existing project structure
- Keep components small and reusable
- Maintain consistency with design system
- Explain approach before generating complex code

Do NOT:

- Use `any` type without justification
- Use hardcoded colors or styles
- Create custom UI outside design system
- Break existing architecture
- Duplicate logic