# Flow
Apertura Carta de Crédito

# Step
Step 1 — Información Inicial

---

# Objective

Collect the initial information required to create a credit letter request.

This step belongs to a multi-step enterprise banking workflow.

---

# Screen Structure

The screen contains:

- Header
- Breadcrumbs
- Stepper
- Accordion sections
- Footer actions

---

# Accordion Sections

## 1. Información General

Fields:
- Oficina Ejecutiva (dropdown)
- Oficina (dropdown)

---

## 2. Información Cliente

Fields:
- Ordenante/Tomador
- Dirección

Radio Group:
- Base de Participantes
- En especial

---

## 3. Beneficiario

Fields:
- ID
- Nombre/Razón Social
- Dirección
- Comuna/Ciudad
- Región/Estado
- País
- Código Postal
- Teléfono
- Fax
- Casilla Banco Privé
- Casilla Postal

Selection Type:
- Dirección
- Casilla Banco de Chile
- Fax
- Casilla Postal

---

## 4. Banco Financiador

Fields:
- Banco identificador
- Dirección

Selection Type:
- Base de Participantes
- En especial

---

## 5. Banco Corresponsal Vista

Fields:
- Banco identificador
- Dirección

Selection Type:
- Base de Participantes
- En especial

---

## 6. Banco Corresponsal Plazo

Collapsed by default.

Supports expandable behavior.

---

## 7. Banco Notificador

Fields:
- Banco identificador
- Dirección

Selection Type:
- Base de Participantes
- En especial

---

## 8. Identificación de la Operación

Fields:
- Importador
- Referencia
- Importación
- Banco Receptor
- Referencia

---

# Footer Actions

Actions:
- Guardar Borrador
- Siguiente

Primary action:
- Siguiente

---

# Interaction Requirements

- Accordion sections support expanded/collapsed states
- Chevron icon rotates on toggle
- Form fields preserve alignment consistency
- Validation states supported on all inputs

---

# Responsive Expectations

Desktop:
- multi-column layout

Tablet:
- reduced columns

Mobile:
- stacked layout